
abstract public class movie {
	String title;
	String genere;
	int duration;
	String director;
}